var searchData=
[
  ['bad_5fauthentication_5fmethod_0',['BAD_AUTHENTICATION_METHOD',['../namespacemqtt.html#a2ac8994dbff700e61e5f756d54c6a1c7a19eae5496864363893408e8dfc03546e',1,'mqtt']]],
  ['bad_5fuser_5fname_5for_5fpassword_1',['BAD_USER_NAME_OR_PASSWORD',['../namespacemqtt.html#a2ac8994dbff700e61e5f756d54c6a1c7ac51a7eb776ad8d8176918c5854e8e596',1,'mqtt']]],
  ['banned_2',['BANNED',['../namespacemqtt.html#a2ac8994dbff700e61e5f756d54c6a1c7aba07960cce92d93244a18be636a5702d',1,'mqtt']]]
];
