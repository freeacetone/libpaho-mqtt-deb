var searchData=
[
  ['reason_5fcode_0',['reason_code',['../classmqtt_1_1disconnect__options__builder.html#a99b0caee7d8c675fee28f187084ccba2',1,'mqtt::disconnect_options_builder']]],
  ['reason_5fcode_5fstr_1',['reason_code_str',['../classmqtt_1_1exception.html#a163c4d1fb8b780dfea5ba30c76bfcf6e',1,'mqtt::exception']]],
  ['reconnect_2',['reconnect',['../classmqtt_1_1async__client.html#a93cad44caab9aa829745477b170eae3d',1,'mqtt::async_client::reconnect()'],['../classmqtt_1_1client.html#ac1d6f930e4f8403eb9c9bd3a6f81ddb1',1,'mqtt::client::reconnect()'],['../classmqtt_1_1iasync__client.html#aba2b3630f09fc47089d8487c6c6cf7cc',1,'mqtt::iasync_client::reconnect()']]],
  ['remove_3',['remove',['../classmqtt_1_1iclient__persistence.html#af570b2e34a6effab5d0cf7d610804929',1,'mqtt::iclient_persistence']]],
  ['reset_4',['reset',['../classmqtt_1_1buffer__ref.html#adb825ca3db27ec312a4aeba1724f2c07',1,'mqtt::buffer_ref']]],
  ['response_5foptions_5',['response_options',['../classmqtt_1_1response__options.html#a0800159be12af6c8da7c2eec8794f3bd',1,'mqtt::response_options::response_options(int mqttVersion=MQTTVERSION_DEFAULT)'],['../classmqtt_1_1response__options.html#a3e377ed49289d438ed9665f9988e0674',1,'mqtt::response_options::response_options(const token_ptr &amp;tok, int mqttVersion=MQTTVERSION_DEFAULT)'],['../classmqtt_1_1response__options.html#aec5e38e91beb16e614b22e686cb6933f',1,'mqtt::response_options::response_options(const response_options &amp;other)']]],
  ['response_5foptions_5fbuilder_6',['response_options_builder',['../classmqtt_1_1response__options__builder.html#af005ccc92e4c0f8fda75ecbce860a25a',1,'mqtt::response_options_builder']]],
  ['restore_5fmessages_7',['restore_messages',['../classmqtt_1_1create__options__builder.html#a23f1d8fa4259c0a68f7ea8ca75911b1d',1,'mqtt::create_options_builder']]],
  ['retained_8',['retained',['../classmqtt_1_1message__ptr__builder.html#ae0691247bc04d47eb1da82d5651ea344',1,'mqtt::message_ptr_builder']]]
];
