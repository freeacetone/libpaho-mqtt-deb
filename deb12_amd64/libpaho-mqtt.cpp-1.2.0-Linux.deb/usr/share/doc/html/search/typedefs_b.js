var searchData=
[
  ['unique_5fptr_5ft_0',['unique_ptr_t',['../classmqtt_1_1ssl__options.html#a76a00863f53d83b0da5b9a2335ee4495',1,'mqtt::ssl_options::unique_ptr_t()'],['../classmqtt_1_1will__options.html#acf6b901a392c8b6f204fdb19904f1716',1,'mqtt::will_options::unique_ptr_t()']]],
  ['update_5fconnection_5fhandler_1',['update_connection_handler',['../classmqtt_1_1async__client.html#a573643b9fdf2f80fd6d5ac82b8e01d0a',1,'mqtt::async_client::update_connection_handler()'],['../classmqtt_1_1client.html#a6ff61b4183a2c3eea6fa608418c4305d',1,'mqtt::client::update_connection_handler()']]]
];
