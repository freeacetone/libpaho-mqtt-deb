var searchData=
[
  ['token_5fptr_913',['token_ptr',['../namespacemqtt.html#a58496a0bf0c96ba40128a62a0f4f4ded',1,'mqtt']]],
  ['topic_5fptr_914',['topic_ptr',['../namespacemqtt.html#abc799f61c488a0c4d5edde6749a6bfa3',1,'mqtt']]]
];
