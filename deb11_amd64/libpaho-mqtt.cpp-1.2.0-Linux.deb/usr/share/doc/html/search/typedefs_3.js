var searchData=
[
  ['delivery_5ftoken_5fptr_891',['delivery_token_ptr',['../namespacemqtt.html#af0ae39eb0c0473cb83d482d6425288e3',1,'mqtt']]],
  ['disconnected_5fhandler_892',['disconnected_handler',['../classmqtt_1_1async__client.html#a6e6609824bce2c6f5e42b04e0b73702e',1,'mqtt::async_client']]]
];
