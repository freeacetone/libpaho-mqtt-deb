var searchData=
[
  ['http_5fheaders_186',['http_headers',['../classmqtt_1_1connect__options__builder.html#a41ec41717403be01dfd75a294947ea41',1,'mqtt::connect_options_builder::http_headers(const name_value_collection &amp;headers) -&gt; self &amp;'],['../classmqtt_1_1connect__options__builder.html#a62597735d3f05fe3ff345a37fec30a31',1,'mqtt::connect_options_builder::http_headers(name_value_collection &amp;&amp;headers) -&gt; self &amp;']]],
  ['http_5fproxy_187',['http_proxy',['../classmqtt_1_1connect__options__builder.html#a1b5cae2241c21549e95b12720279f36b',1,'mqtt::connect_options_builder']]],
  ['https_5fproxy_188',['https_proxy',['../classmqtt_1_1connect__options__builder.html#a67cf76a81c6658fe88771578bc9c0c6c',1,'mqtt::connect_options_builder']]]
];
